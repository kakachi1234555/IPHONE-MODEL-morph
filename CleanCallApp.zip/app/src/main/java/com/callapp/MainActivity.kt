package com.callapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.twilio.Twilio
import com.twilio.rest.api.v2010.account.Call
import com.twilio.type.PhoneNumber
import java.net.URI

class MainActivity : AppCompatActivity() {

    // Twilio credentials (replace with your credentials)
    private val ACCOUNT_SID = "ACXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
    private val AUTH_TOKEN = "your_auth_token"
    private val TWILIO_PHONE_NUMBER = "+1XXXXXXXXXX"

    private lateinit var phoneNumberEditText: EditText // Input for phone number
    private lateinit var callButton: Button          // Button to make the call

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        phoneNumberEditText = findViewById(R.id.phoneNumber)
        callButton = findViewById(R.id.callButton)

        // Initialize Twilio SDK with account SID and auth token
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN)

        // Set up the call button click listener
        callButton.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                val phoneNumber = phoneNumberEditText.text.toString().trim()
                // Validate phone number
                if (phoneNumber.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Veuillez entrer un numéro de téléphone", Toast.LENGTH_SHORT).show()
                    return
                }

                // Make the call
                makeCall(phoneNumber)
            }
        })
    }

    // Function to make the call using Twilio API
    private fun makeCall(phoneNumber: String) {
        try {
            // Make the call using Twilio's Call API
            val call = Call.creator(
                PhoneNumber(phoneNumber),
                PhoneNumber(TWILIO_PHONE_NUMBER),
                URI("http://demo.twilio.com/docs/voice.xml") // URL for handling the call (Twilio Voice XML)
            ).create()

            // Show a success message
            Toast.makeText(this, "Appel en cours vers : $phoneNumber", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // Show error message if call fails
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
